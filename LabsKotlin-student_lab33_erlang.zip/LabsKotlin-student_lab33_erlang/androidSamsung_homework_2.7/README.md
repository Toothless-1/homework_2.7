# androidSamsung_homework_2.7
